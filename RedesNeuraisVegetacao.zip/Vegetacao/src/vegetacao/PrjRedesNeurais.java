
package vegetacao;

import weka.classifiers.evaluation.Evaluation;
import weka.classifiers.functions.LinearRegression;
import weka.classifiers.functions.MultilayerPerceptron;
import weka.core.Instances;
import weka.core.Utils;
import weka.experiment.InstanceQuery;

public class PrjRedesNeurais {
    /**
     * @param args the command line arguments
     */
	static MultilayerPerceptron mp;
    public static void main(String[] args) throws Exception {

        InstanceQuery queryTreino = new InstanceQuery();
        queryTreino.setUsername("root");
        queryTreino.setPassword("");
        queryTreino.setQuery("SELECT * FROM vegetacao_treinos");

        Instances insTreino = queryTreino.retrieveInstances();
	    
        insTreino.setClassIndex(insTreino.numAttributes()-1);
        mp = new MultilayerPerceptron();
        mp.setOptions(Utils.splitOptions("-L 0.3 -M 0.2 -N 500 -V 0 -S 0 -E 20 -H a")); 
        mp.setAutoBuild (true);
        mp.setLearningRate(0.1);
        mp.setMomentum(0.2);

        mp.buildClassifier(insTreino);

        InstanceQuery queryTeste = new InstanceQuery();
        queryTeste.setUsername("root");
        queryTeste.setPassword("");
        queryTeste.setQuery("SELECT * FROM vegetacao_teste");

        Instances insTeste = queryTeste.retrieveInstances();

        insTeste.setClassIndex(insTeste.numAttributes()-1);

        Evaluation eval = new Evaluation(insTreino);
        eval.evaluateModel(mp,insTeste);
        System.out.println(eval.toSummaryString());

      //  avaliarEntrada();
    }
    
    public static void avaliarEntrada() throws Exception{
	    InstanceQuery queryCalculo = new InstanceQuery();
	    queryCalculo.setUsername("root");
	    queryCalculo.setPassword("");
	    queryCalculo.setQuery("SELECT * FROM vegetacao_calculo Order by rand() Desc Limit 1");
	     
	    Instances insCalculo = queryCalculo.retrieveInstances();	    
	    insCalculo.setClassIndex(insCalculo.numAttributes()-1);
	    
	    double[] pred = mp.distributionForInstance(insCalculo.instance(0));
	    System.out.print("ID: " + insCalculo.instance(0).value(0));
	    System.out.print(", Real: " + (int) insCalculo.instance(0).classValue());
	    System.out.println(", Predito: " + (int) pred[0]);      
    }
    
        
    //Usamos este método para calcular a rede neural
        public static double calcular() throws Exception{
            double[] pred = {};

            InstanceQuery queryTreino = new InstanceQuery();
            queryTreino.setUsername("root");
            queryTreino.setPassword("");
            queryTreino.setQuery("SELECT * FROM vegetacao_treinos");

            Instances insTreino = queryTreino.retrieveInstances();

            insTreino.setClassIndex(insTreino.numAttributes()-1);
            mp = new MultilayerPerceptron();
            mp.setOptions(Utils.splitOptions("-L 0.3 -M 0.2 -N 500 -V 0 -S 0 -E 20 -H a")); 
            mp.setAutoBuild (true);
            mp.setLearningRate(0.2);
            mp.setMomentum(0.2);

            mp.buildClassifier(insTreino);

            InstanceQuery queryTeste = new InstanceQuery();
            queryTeste.setUsername("root");
            queryTeste.setPassword("");
            queryTeste.setQuery("SELECT * FROM vegetacao_teste");

            Instances insTeste = queryTeste.retrieveInstances();

            insTeste.setClassIndex(insTeste.numAttributes()-1);

            Evaluation eval = new Evaluation(insTreino);
            eval.evaluateModel(mp,insTeste);
            System.out.println(eval.toSummaryString());
        
          InstanceQuery queryCalculo = new InstanceQuery();
	    queryCalculo.setUsername("root");
	    queryCalculo.setPassword("");
	    queryCalculo.setQuery("SELECT * FROM vegetacao_calculo Limit 1");
	     
	    Instances insCalculo = queryCalculo.retrieveInstances();	    
	    insCalculo.setClassIndex(insCalculo.numAttributes()-1);
	    
	    pred = mp.distributionForInstance(insCalculo.instance(0));
	    System.out.print("ID: " + insCalculo.instance(0).value(0));
	    System.out.print(", Real: " + (int) insCalculo.instance(0).classValue());
	    System.out.println(", Predito: " + pred[0]);
                
           return pred[0];
		    
         }
}
