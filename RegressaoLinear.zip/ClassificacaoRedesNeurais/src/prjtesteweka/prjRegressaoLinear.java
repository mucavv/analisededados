package prjtesteweka;



import weka.classifiers.evaluation.*;
import weka.classifiers.functions.LinearRegression;
import weka.core.Instances;
import weka.experiment.InstanceQuery;

public class prjRegressaoLinear {
	
	static LinearRegression lr;
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		InstanceQuery queryTreino = new InstanceQuery();
		queryTreino.setUsername("root");
		queryTreino.setPassword("");
		queryTreino.setQuery("SELECT * FROM toyotacarros");
	     
	    Instances ins = queryTreino.retrieveInstances();
	    
	    ins.setClassIndex(ins.numAttributes()-1);

		lr = new LinearRegression();
		lr.buildClassifier(ins);
		
		// evaluate classifier and print some statistics
		Evaluation eval = new Evaluation(ins);
		eval.evaluateModel(lr,ins );
		System.out.println(eval.correlationCoefficient());
		//System.out.println(eval.toSummaryString());
		//avaliarTodos();
		avaliarEntrada();
	}
	
	 public static void avaliarEntrada() throws Exception{
		    InstanceQuery queryCalculo = new InstanceQuery();
		    queryCalculo.setUsername("root");
		    queryCalculo.setPassword("");
		    queryCalculo.setQuery("SELECT * FROM toyotacarros_calcula Order by rand() Desc Limit 1");
		     
		    Instances insCalculo = queryCalculo.retrieveInstances();
		    
		    insCalculo.setClassIndex(insCalculo.numAttributes()-1);
		    
		    double pred = lr.classifyInstance(insCalculo.instance(0));
                    System.out.print("Equação: " + lr);
		    System.out.print("ID: " + insCalculo.instance(0).value(0));
		    System.out.print(", Real: " + insCalculo.instance(0).classValue());
                    System.out.println(", Predito: " +  pred);
                    System.out.println(", % Desvio do Valor Real: " +  (Math.abs(pred-insCalculo.instance(0).classValue())/insCalculo.instance(0).classValue())*100);
	}
         
         public static void avaliarTodos() throws Exception{
             
                    InstanceQuery queryCalculoTodos = new InstanceQuery();
		    queryCalculoTodos.setUsername("root");
		    queryCalculoTodos.setPassword("");
		    queryCalculoTodos.setQuery("SELECT * FROM toyotacarros_calcula");
		     
		    Instances insCalculo = queryCalculoTodos.retrieveInstances();
		    
		    insCalculo.setClassIndex(insCalculo.numAttributes()-1);
         
		    for(int i = 0; i<insCalculo.size(); i++){
                        double pred = lr.classifyInstance(insCalculo.instance(i));
                    
                        System.out.print("ID: " + insCalculo.instance(i).value(0));
                        System.out.print(", Real: " + insCalculo.instance(i).classValue());
                        System.out.print(", Predito: " +  pred);
                        System.out.print(", % Desvio do Valor Real: " +  (Math.abs(pred-insCalculo.instance(i).classValue())/insCalculo.instance(i).classValue())*100);
                        System.out.println(" ");
                    }
		    
         }
	   
        
        public static double calcular() throws Exception{
                double pred = 0;
                InstanceQuery queryTreino = new InstanceQuery();
                queryTreino.setUsername("root");
                queryTreino.setPassword("");
                queryTreino.setQuery("SELECT * FROM toyotacarros");
	     
                Instances ins = queryTreino.retrieveInstances();
	    
                ins.setClassIndex(ins.numAttributes()-1);

		lr = new LinearRegression();
		lr.buildClassifier(ins);
		
		// evaluate classifier and print some statistics
		Evaluation eval = new Evaluation(ins);
		eval.evaluateModel(lr,ins );
		System.out.println(eval.correlationCoefficient());
                
                InstanceQuery queryCalculoTodos = new InstanceQuery();
                queryCalculoTodos.setUsername("root");
                queryCalculoTodos.setPassword("");
                queryCalculoTodos.setQuery("SELECT * FROM toyotacarros_calcula");

                Instances insCalculo = queryCalculoTodos.retrieveInstances();

                insCalculo.setClassIndex(insCalculo.numAttributes()-1);

                for(int i = 0; i<insCalculo.size(); i++){
                    pred = lr.classifyInstance(insCalculo.instance(i));

                    System.out.print("ID: " + insCalculo.instance(i).value(0));
                    System.out.print(", Real: " + insCalculo.instance(i).classValue());
                    System.out.print(", Predito: " +  pred);
                    System.out.print(", % Desvio do Valor Real: " +  (Math.abs(pred-insCalculo.instance(i).classValue())/insCalculo.instance(i).classValue())*100);
                    System.out.println(" ");
                }
                
                return pred;
		    
         }
}
